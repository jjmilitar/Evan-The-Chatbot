/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evanthechatbot;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.lang.String;

/**
 *
 * @author Gecarane
 */
public class chatbotProcess {
    static String KnowledgeBase[][][] = new String[10][2][100];
    static int premiseIndex[] = new int[100];
    static int matchCount[] = new int[100];
    static  ArrayList<String> token = new ArrayList<String>();
    static  ArrayList<String> match = new ArrayList<String>();
    static String output = "";
    static int index;
    public static String input = new String("");
    public static String inputBackup = new String("");
    
    public static void retrieveKnowledge(){
        int count = 0;
        int count2 = 0;
        int lineC = 0;
        try{
            File knowledge = new File("knowledgeBase.txt");
            Scanner scanner = new Scanner(knowledge);
            while(scanner.hasNext()){
                String line = scanner.nextLine();
                if((!(line.equals("next")))&& (!(line.equals("input")))&&(!(line.equals("respond")))){
                KnowledgeBase[lineC][count2][count] = line;
                lineC++;
                }
                if(line.equals("next")){
                    count++;
                    lineC = 0;
                }
                if(line.equals("input")){
                    count2 = 0;
                    lineC = 0;
                }
                if(line.equals("respond")){
                    count2 = 1;
                    lineC = 0;
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void read(){
        for(int a=0;a<100;a++){
            for(int b=0;b<10;b++){
                output+=KnowledgeBase[b][0][a] + "\n";
            }
        }
    }
    public static void initializeCount(){
        for(int a=0;a<matchCount.length;a++){
            premiseIndex[a] = a;
            matchCount[a] = 0;
        }
    }
    public static void situationRecognizer(){
        input = input.toUpperCase();
        input = input.replaceAll("[\\p{Punct}&&[^0-9]&&[^,]]", "");
    }
    public static void situationSetter(){
        inputBackup = input;
        try{
            for(String word : input.split(" ")) {
                token.add(word);
                }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        for(int b=0;b<token.size();b++){
            JOptionPane.showMessageDialog(null, token.get(b));
        }
    }
    public void forwardChaining(){
        int count = 0;
        try{
        while(!token.isEmpty()){
            String premise = token.remove(0);
            for(int b=0;b<KnowledgeBase.length;b++){
            for(int c=0;c<10;c++){
                if(premise.equals(KnowledgeBase[c][0][b])){
                    match.add(KnowledgeBase[c][1][b]);
                    matchCount[b]+= 1;
                    //output+=KnowledgeBase[c][0][b];
                }
            }
            }
          }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        int max = getMax();
        selectResponse(max);
    }
    public int getMax(){
        int maxValue = matchCount[0];
        for(int d=1;d<matchCount.length;d++){
            if(matchCount[d]>maxValue){
                 maxValue = matchCount[d];
            }
        }
        return maxValue;
    }
    public void selectResponse(int max){
        for(int k=0;k<matchCount.length;k++){
         if(matchCount[k]==max){
             index = k;
         }   
        }
    }
    public void findResponse(){
       int random = ((int) (Math.random()*(8 - 0))) + 0;
        output+=KnowledgeBase[0][1][index] + index;
    }
}
