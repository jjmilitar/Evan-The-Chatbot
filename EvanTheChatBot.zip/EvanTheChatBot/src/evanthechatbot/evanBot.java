/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evanthechatbot;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author Gecarane
 */
public class evanBot {
    static int responseCount = 6;
    static String punc = "?!.;,";
    static String conversation = "";
    static KnowledgeBase b = new KnowledgeBase();
    public static Vector<String> listResponse = new Vector<String>(responseCount);
    public static String input = "";
    public static String response = "";
    public static String prevInput = "";
    public static String prevRes = "";
    public static String evt = "";
    public static String prevEvt = "";
    public static String tempInput = "";
    public static String subj = "";
    public static String keyword = "";
    public static String inputBackup = "";
    public static boolean end = false;
    static int premiseIndex[] = new int[100];
    static int matchCount[] = new int[100];
    static boolean check = false;
    static boolean check2 = true;
    static int repetition = 0;
    static  ArrayList<String> token = new ArrayList<String>();
    static  ArrayList<String> match = new ArrayList<String>();
    static ArrayList<String> recordInput = new ArrayList<String>();
    
	public static void getInput()
	{
                conversation+="\n"+"Evan: ";
                situationRecognizer();
	}
        public static void situationRecognizer()
        {
            check = false;
            if(input.length()!=0){
            check = checkRecordInput();
            recordInput.add(input);
            check2 = true;
            }
            else if(input.length()==0){
                repetition++;
                check2 = false;
            }
            prevInput = input;
	    input = eliminatePunc(input);
	    input = input.toUpperCase();
	    input = " " + input + " ";
        }
	public static void situationSetter()
	{
                prevRes = response;
                evt = "BOT UNDERSTAND**";
                
		if((repetition==1)&&(!check2))/*(input.length() == 0 && prevInput.length() != 0)*/
		{
			handle_event("NULL INPUT**");
		}
		else if((repetition>=2)&&(!check2))/*(input.length() == 0 && prevInput.length() == 0)*/
		{
			handle_event("NULL INPUT REPETITION**");
		}
		else if (check)/*(prevInput.length() > 0 && ((input == prevInput) || 
			(input.indexOf(prevInput) != -1) ||(prevInput.indexOf(input) != -1)))*/
		{
			handle_user_repetition();
		}
		else
		{
                        forwardChaining();
			findMatch();
		}
                checkingResponse();
	}

	public static void checkingResponse(){
            if(input.indexOf("Goodbye") != -1)
		{
			end = true;
		}
	    if(!(listResponse.size() > 0))
		{
			handle_event("BOT DON'T UNDERSTAND**");
		}
	    
	    if(listResponse.size() > 0)
		{
			selectResponse();
                        
			if(response.indexOf("*") != -1)
                        {
                            find_subject(); 
                            subj = replace(subj); 
                            subj = subj.trim();
                            response = response.replace("*", " " + subj);
                         }

			if(prevRes.length() > 0 && response == prevRes)
			{
				handle_repetition();
			}
			printResponse();
		}
        }
        public static boolean checkRecordInput(){
            for(int k=0;k<recordInput.size();k++){
                if(input.equals(recordInput.get(k))){
                    check = true;
                }
                else{
                    check = false;
                }
            }
            return check;
        }
         public static void splitInput(){
        inputBackup = input;
        try{
            for(String word : inputBackup.split(" ")) {
                token.add(word);
                }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void forwardChaining(){
        int count = 0;
        boolean check;
        try{
        while(!token.isEmpty()){
            String premise = token.remove(0);
            for(int a=0;a<b.KnowledgeBase.length;a++){
                for(int c=0;c<10;c++){
                    if(premise.equals(b.KnowledgeBase[c][0][a])){
                         match.add(b.KnowledgeBase[c][1][a]);
                         matchCount[a]+= 1;
                         int j = premiseIndex[a];
				if (matchCount[a] == 0){
					String head = token.get(a);
					if (head.equals(inputBackup)){
						check = true;
                                        }
					token.add(head);					
				}
                        }
                      }
                  }
             }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        int max = getMax();
        selectResponse(max);
    }
    public static int getMax(){
        int maxValue = matchCount[0];
        for(int d=1;d<matchCount.length;d++){
            if(matchCount[d]>maxValue){
                 maxValue = matchCount[d];
            }
        }
        return maxValue;
    }
    public static void selectResponse(int max){
        for(int k=0;k<matchCount.length;k++){
         if(matchCount[k]==max){
             int indexMax = k;
         }   
        }
    }
    public static void findResponse(){
       int random = ((int) (Math.random()*(8 - 0))) + 0;
        
    }
         public static void retrieveKnowledge(){
        int count = 0;
        int count2 = 0;
        int lineC = 0;
        try{
            File knowledge = new File("knowledgeBase.txt");
            Scanner scanner = new Scanner(knowledge);
            while(scanner.hasNext()){
                String line = scanner.nextLine();
                if((!(line.equals("next")))&& (!(line.equals("input")))&&(!(line.equals("respond")))){
                b.KnowledgeBase[lineC][count2][count] = line;
                lineC++;
                }
                if(line.equals("next")){
                    count++;
                    lineC = 0;
                }
                if(line.equals("input")){
                    count2 = 0;
                    lineC = 0;
                }
                if(line.equals("respond")){
                    count2 = 1;
                    lineC = 0;
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void read(){
        for(int a=0;a<100;a++){
            for(int b=0;b<10;b++){
                
            }
        }
    }
    public static void initializeCount(){
        for(int a=0;a<matchCount.length;a++){
            premiseIndex[a] = a;
            matchCount[a] = 0;
        }
    }
	public static void findMatch() 
	{
                char firstChar;
		char lastChar;
		listResponse.clear();
		String bestKeyWord = "";
		Vector<Integer> index = new Vector<Integer>(responseCount);

		for(int i = 0; i < b.KnowledgeBase.length; ++i) 
		{
			String[] listKeyword = b.KnowledgeBase[i][0];
			for(int j = 0; j < listKeyword.length; ++j)
			{
				String keyWord = listKeyword[j];
				firstChar = keyWord.charAt(0);
				lastChar = keyWord.charAt(keyWord.length() - 1);
				keyWord = elimPunc(keyWord, "_");
				keyWord = " " + keyWord + " ";
				int keyPos = input.indexOf(keyWord);

				if( keyPos != -1 ) 
				{
					if(checkKeyword(keyWord, firstChar, lastChar, keyPos) )
					{
						continue;
					}
					if(keyWord.length() > bestKeyWord.length())
					{
						bestKeyWord = keyWord;
						index.clear();
						index.add(i);
					}
					else if(keyWord.length() == bestKeyWord.length())
					{
						index.add(i);
					}
				}
			}
		}
		if(index.size() > 0)
		{
			keyword = bestKeyWord;
			Collections.shuffle(index);
			int rIndex = index.elementAt(0);
			int rSize = b.KnowledgeBase[rIndex][1].length;
			for(int j = 0; j < rSize; ++j) 
			{
				listResponse.add(b.KnowledgeBase[rIndex][1][j]);
			}
		}
	}

	public static void find_subject()
	{
		subj = "";
		int pos = input.indexOf(keyword);
		if(pos != -1)
		{
			subj = input.substring(pos + keyword.length() - 1,input.length());		
		}
	}
	public static String replace( String str )
	{
		boolean checkReplace = false;
		for(int i = 0; i < b.replaceList.length; ++i)
		{
			String first = b.replaceList[i][1];
			first = " " + first + " ";
			String second = b.replaceList[i][0];
			second = " " + second + " ";
			
			String backup = str;
			str = str.replace(first, second);
			if(str != backup) 
			{
				checkReplace = true;
			}
		}

		if(!checkReplace)
		{
			for( int i = 0; i < b.replaceList.length; ++i )
			{
				String first = b.replaceList[i][0];
				first = " " + first + " ";
				String second = b.replaceList[i][1];
				second = " " + second + " ";
				str = str.replace(first, second);
			}
		}
		return str;
	}
        
	static boolean checkKeyword(String keyword, char firstChar, char lastChar, int pos)
	{
		boolean bWrongPos = false;
		pos += keyword.length();
		if( (firstChar == '_' && lastChar == '_' && input != keyword) ||
			(firstChar != '_' && lastChar == '_' && pos != input.length()) ||
			(firstChar == '_' && lastChar != '_' && pos == input.length()) )
		{
			bWrongPos = true;
		}
		return bWrongPos;
	}
	
	public static void handle_repetition()
	{
		if(listResponse.size() > 0)
		{
			listResponse.removeElementAt(0);
		}
		if(listResponse.size() == 0)
		{
			tempInput = input;
                        input = evt;

			findMatch();
			input = tempInput;
		}
		selectResponse();
	}
	
	public static void handle_user_repetition()
	{
               handle_event("REPETITION T1**");
		if(input.length() > 0 && input == prevInput) 
		{
			handle_event("USER_REPEAT");
		}
		else if(input.length() > 0 &&(input.indexOf(prevInput) != -1 || prevInput.indexOf(input) != -1))
		{
			handle_event("USER_REPEAT2");
		}
	}
	
	public static void handle_event(String str)
	{
		save_prev_event();
                evt = str;
		tempInput = input;
		str = " " + str + " ";
                input = str;
		
		if(!(evt.length() > 0 && evt == prevEvt)) 
		{
			findMatch();
		}

		input = tempInput;
	}
	
	public static void startConvo()
	{
		handle_event("START");
		selectResponse();
		printResponse();
	}

	public static void selectResponse() {
		Collections.shuffle(listResponse);
		response = listResponse.elementAt(0);
	}

	public static void save_prev_event() {
		prevEvt = evt;
	}
	public static void printResponse()  {
		if(response.length() > 0) {
                        conversation+=response+"\n";
		}
	}

	static boolean isPunc(char ch) {
		return punc.indexOf(ch) != -1;
	}
	
	// removes punctuation and redundant
	// spaces from the user's input
	static String eliminatePunc(String inputPunc) {
		StringBuffer temp = new StringBuffer(inputPunc.length());
		char prevChar = 0;
		for(int i = 0; i < inputPunc.length(); ++i) {
			if((inputPunc.charAt(i) == ' ' && prevChar == ' ' ) || !isPunc(inputPunc.charAt(i))) {
				temp.append(inputPunc.charAt(i));
				prevChar = inputPunc.charAt(i);
			}
			else if(prevChar != ' ' && isPunc(inputPunc.charAt(i)))
			{
				temp.append(' ');
				prevChar = ' ';
			}
		}
		return temp.toString();
	}
	
	static String elimPunc(String str, String punc)
	{
		StringBuffer temp = new StringBuffer(str);
		int index1 = temp.indexOf(punc);
		int index2 = temp.lastIndexOf(punc);
		if(index1 != -1)
		{
			temp.deleteCharAt(index1);
			index2--;
		}
		if(index2 > -1)
		{
			temp.deleteCharAt(index2);
		}
		return temp.toString();
	}
}
