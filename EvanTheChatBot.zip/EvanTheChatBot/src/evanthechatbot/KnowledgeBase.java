package evanthechatbot;


import java.io.File;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gecarane
 */
public class KnowledgeBase {
    static String output = "";
    //static String KnowledgeBase[][][] = new String [10][2][100];
    static String KnowledgeBase[][][] = {
                        {{"ANGER","ANGRY","MAD","HATE"},
			{"Be quick to listen, slow to speak, and slowto get angry.\n"
                            + "-James 1:19",
			 "James says anger doesn't make anything right.",
			 "You should be patient and listen to what the otherperson has\n"
                           + "to say first, before you speak.",
                          "Instead of focusing on how you've been hurt or why you're right,\n"
                            + "it's better to focus on being patient and loving others."}
			},
                        {{"APPEARANCE","UGLY","PANGIT","NERD","WEIRD","BADUY"},
			{"People judge by outward apperance, but the LORD\nlooks at the \n"
                         + "heart. - 1 Samuel 16:7",
			 "When people judge you by hair, face, or clothing, they may\n"
                          + "overlook you if you don't stack up to the latest model.",
			 "Real good looks depebd on your heart attitude, not on what you \n"
                           + "like on the outside."}
			},
                        
                        {{"ATTITUDE", "BAD ATTITUDE","BAD","BITTER","BITTERNESS","MOVE ON"},
			{"Get rid of all bitterness... Instead, be kind to each other. \n"
                         + "- Ephesians 4:31 - 32",
			 "Thinking angry thoughts won't help.",
			 "If you stay angry angry, you'll only hurtyourself in the long \n"
                        + "run."}
			},
                        {{"BOAST", "BOASTING","BRAG","BRAGGING","YABANG","MAYABANG"},
			{"If you want to boast, boast only about the LORD.\n"
                        + "- 2 Corinthians 10:17"}
			},
                        {{"COMPLAN", "COMPLAIN","DISCONTENTED"},
			{"When things went wrong, the Israelites complained. Instead of\n"
                         + "remembering God and his faithfulness, they blew it!\n" +
                          "The Bible says complaining is wrong.",
			 "When we complain, we fail to show allreciation for what\n"
                        + " God has done.",
			 "Complaining builds attitudes of resentment and bitterness."}
			},
                        {{"CONFIDENCE", "CONFIDENT","SHY","NERVOUS","AFRAID"},
			{"God knows you and all your abilities, and he will help you\n"
                         + " succeed if it's something he wants you to do.",
			 "Ask God for help and guidance. He will help you."}
			},
                         {{"DISCOURAGEMENT", "DISCOURAGE","HOPELESS", "FEELING DOWN", "DOWN FEELINGS","FAIL","ABANDON","AGAINST"},
			{"If you feel hopeless, ask God to remind you who he is: the always\n"
                         + "faithful, always merciful God.",
			 "Your \"down\" feelings won't last forever, but God does.",
			 "People may turn against you, friends may fail you, and family members\n"
                        + "may abandon you; but God is faithful.\nHe stands with you and for you."}
			},
                         {{"EMPTY", "NOTHING","USELESS"},
			{"When you feel empty, you can turn to our strong, powerful God.",
			 "Read the Bible - it's a record of the amazing things he's done,\n"
                         + "including how he cared for people even when thy rebelled \n" +
                        " against him. He's waiting for you to turn to him so he can fill\n"
                         + "that empty spot with his peace and joy."}
			},
                         {{"WEAK", "FEAR","DANGER"},
			{"If you're uncomfortable when facing danger, you're not alone.",
			 "The Bible is full of people who felt weak in the face of tough\n"
                            + "situations, yet God used them mightily because they \n" +
                            "trusted him to overcome their weakness.",
                        "God is with you always, and help you triumph over your fears."}
			},
                          {{"GRIEVE", "GRIEVING","CRY","CRIED","TEARS"},
			{"Jesus also cried. When his friend, Lazarus, died, Jesus wept openly,\n"
                        + "showing deep sorrow. He wasn't afraid of anyone calling him a sissy.\n",
			 "Jesus understands your tears - and becaus he cried, it's okay\n"
                        + "for you to cry, too."}
			},
                          {{"GUILT", "CONSCIENCE","CONFESS","STRAY"},
			{"How can you keep your conscience clear? Treasure your faith in\n"
                            + "Christ more than anything else, and do what is right.",
			 "Ask you walk with God, he'll speak to you, letting you know\n"
                            + "the difference between right and wrong. ",
                        "If you do stray, confess your sin to God, and you will be forgiven."}
			}, 
                          {{"HUMBLE", "HUMILITY","FORGIVE","SINNER","ADMIT"},
			{"God will hear and forgive you when you're humble - when you admit\n"
                        + "that you're sinner and that you need God.",
			 "Depend on him for everything - from your clothes, to your home,\n"
                            + "to your family, to your very life.",
                        "Being humble means you realize thatGod is very big and that you're\n"
                        + "very small and powerless in comparison."}
			}, 
                          {{"INSECURITY", "INSECURE"},
			{"If it seems as if everybody is against you, remember that God\n"
                         + "is for you!",
                        "God is so much for you that he gave Christ to save you - and \n"
                        + "he'll give you everything else you need!"}
			}, 
                          {{"LOVE", "I'M INLOVE","INLOVE","LOVED"},
			{"God will always love you - even when it seems no oe else does.\n"
                        + "The fact that hes sent Jesus, his Son, to die for you is to \n" +
                        "proof of that unending love.",
			 "God is love.",
                        "God's love for you is so great that it'll never end."}
			}, 
                         {{"REVENGE", "ENEMIES"},
			{"When others hurt us deeply, we often feel like giving them\n"
                         + "what they deserve.",
			 "God says to leave revenge up to him.",
                        "We need to let him handle our enemies."}
			}, 
                          {{"JEALOUS", "JEALOUSY"},
			{"Jealously isn't a modern - day disease - it was a problem\n"
                            + "for King Saul of Israel as well!",
			 "There is always someone who is more talented, better looking,\n"
                        + "or materially better off.",
                        "To avoid becoming jealous, we need to be thankful for what we\n"
                        + "have and happy for others for what they have."}
			}, 
                          {{"SECOND CHANCE", "CHANCES","FORGIVEN","FORGIVE","FORGET"},
			{"The story of Hosea and his sinful wife, Gomer, is the story\n"
                        + "of God and his sinful people Israel. Although the people \n" +
                        "sinned, God gave them a second chance.",
			 "God forgave and forgot your sins. And He asks you to do the\n"
                         + "same thing: forgive and forget.",
                        "Forgiving and forgetting doesn't mean you should continue taking\n"
                         + "abuse from a hurtful, abusive person."}
			}, 
                           {{"BARKADA", "B.I.","PEER PRESURE","BAD INFLUENCE"},
			{"The best way to handle peer pressure is first of all to commit\n"
                            + "yourself to pleasing God and ghen stay faithful to him.",
			 "We all want to be liked, but always trying to please others can\n"
                        + "lead us to do what's wrong and even to abandon God.",
                        "The Israelites gave in to the pressures of the sinful people\n"
                        + " around them, and this led to disaster.",
                        "Look for friends who will encourage you to do good, and don't be\n"
                        + "afraid to be a person who takes a stand for what you know is right."}
			}, 
                           {{"ABORTION", "ABORT","BABY","JUST HAPPENED", "PREGNANT","PREGNANCY"},
			{"You didn't plan on getting pregnant or to have a baby; it\n"
                     + "\"just happened\". And all the sorrys in the world won't change \n" +
                        "the fact that you now have a baby.",
			 "God says all children are special, even if you didn't plan them.",
                        "Choose  to give your child life, and God to help you through\n"
                        + "any difficulty.",
                        "Look for friends who will encourage you to do good, and don't be\n"
                        + "afraid to be a person who takes a stand for what you know is right."}
			}, 
                           {{"HOMOSEXUALITY","HOMOSEXUAL","GAY","LESBIAN","BISEXUAL","TRASGENDER","LGBT"},
			{"There were homosexual in Paul's day. But God forbids such behavior,\n"
                            + "saying it's not what he designed to be.",
			 "His plan is one man, one woman, in marriage for lifetime.",
                        "If you have sexual desires, you can and must resist acting on them.\n"
                         + "Ask God and a trusted Christian counselor for help."}
			}, 
                           {{"LUST","SEXY","DROOLING"},
			{"If you're drooling over the opposite sex, put a hold on\n"
                         + "your hormones.",
			 "Instead of thinking how sexy someone looks, focus on qualities\n"
                        + "God values such as a person's character and whether he or she\n"
                            + "has a relationship with Christ.",
                        "As you turn your thoughts over to God each day, he'll help you\n"
                        + "keep your mind pure."}
			}, 
                           {{"PORNOGRAPHY","PORN","BOLD","SEXY","CURIOUS"},
			{"Sure, you're curious.  But if you act on that desire, it'll hurt\n"
                        + "you now and in the future.",
			 "According to Jesus, looking at those pictures to inflame your lust\n"
                        + "is just the same as committing adultery.",
                        "Even if no one else knows, God will. And once you read dirty magazines\n"
                        + "or watch dirty videos, its images will be imprinted in your mind.",
                        "It's better to keep a clean mind and heart and learn to view people\n"
                        + "as God does: with an eternal worth that goes beyond their physical\n"
                        + "appearance."}
			},
                          {{"SUICIDE","_I WANT TO DIE"},
			{"Don't do it! Ask the God who created you to help you know his love.",
			 "Call a friend. Seek help from your pastor. Call on God\n"
                        + "through prayer.",
                        "Everyone goes though times. Allow God and others to help you\n"
                        + "through them.",
                        "There are brighter days ahead. God can restore your joy.",
                        "God has a good plan for your life, and it is up him to decide\n"
                        + "your time to die."}
			}, 
                        {{"SMOKING","SMOKE","DRUGS","SHABU","COCAINE","MARIJUANA","PARTY DRUGS"},
			{"If you live in a building owned by someone else, you live by\n"
                         + "the owner's rules, right? In the same way, your body belongs \n" +
                           "to God, so you should keep it healthy and strong for him.",
			 "You shouldn't overeat, and you shouldn't smoke or drugs.",
                        "Cigarettes and also drugs are toxic to your body, they will\n"
                         + "shorten your life span.",
                        "Keep your body healthy for God!"}
			}, 
                        {{"DEATH","DIE"},
			{"Death is frightening because you can't stop it.",
			 "Only one person can walk with you through death's \"dark valley\"\n"
                        + "and bring you safely to the other side - God, who can \n" +
                           "give you everlasting life.",
                        "Everyone will die sometime. Walk each day with Jesus, and live\n"
                        + "your life fully one day at a time."}
			},   
                         {{"END OF THE WORLD","END","WORLD"},
			{"It's not if the world will end, it's when.",
			 "The present earth won't last forever, because God will destroy\n"
                        + "it when the time is right.",
                        "God promises that he'll create a new one. We don't know exactly\n"
                         + "what it'll be like, but we do know that those who trust \n" +
                        "God will live there forever. Will you be there?"}
			}, 
                         {{"ETERNAL LIFE","ETERNAL","FOREVER","MAY FOREVER","WALANG FOREVER"},
			{"Everyone will live forever; it's just a question of where.",
                        "Do you want to live forever in blessing or in punishment?",
                        "If you don't believe Jesus Christ, God's Son, died for your sins,\n"
                        + "you'll go to hell when you die. But if you've accepted \n" +
                        "Jesus Christ as your Savior, you'll live forever in heaven with him!",
                        "Choose life, and enjoy the blessings of eternity. MAY FOREVER!"}
			}, 
                         {{"HEAVEN"},
			{"Heaven is definitely real.",
                        "Jesus' words show that the way to eternal life, though you can't\n"
                         + "see it, is as secure as God's unchanging love.",
                        "He has already prepared the way to heaven for you. If you've chosen\n"
                          + "to believe in him, your room's ready and waiting!",
                        "Choose life, and enjoy the blessings of eternity. MAY FOREVER!"}
			}, 
                         {{"_WHO IS GOD","GOD"},
			{"God is Spirit. He's the source of all life. That means he isn't\n"
                        + "a physical being like you or me, limited to one place and time.",
                        "He's present everywhere and he sees everything you do.",
                        "He is everywhere you go, and he hears every word you speak."}
			}, 
                         {{"_WHO IS JESUS","JESUS"},
			{"He is God's Son.",
                        "God the Father sent him to live thirty - three years on earth, teaching\n"
                         + "and doing miracles to point people to heaven.",
                        "Jesus die on the cross for your sins. Jesus didn't stay in the grave,\n"
                        + "he rose againn and now in heaven with God!"}
			}, 
                         {{"PRAY","PRAYER","ASK"},
			{"God wants you to have faith in him, to be persistent.",
                        "Don't quit asking God for answers. He \"will\" answer in his way,\n"
                        + "in his time.",
                        "If you're tempted to quit praying when you don't \"hear\" anything,\n"
                         + "remember Jesus' promise: If your faith in God is biased on his \n"
                         + "promises, you'll have what you pray for.",
                        "When it comes to taking to God, never give up!"}
			}, 
                          {{"PROTECTION","PROTECT","SAFE","SHIELD"},
			{"Because we live in a world filled with sin, it's important to\n"
                        + "ask God to keep you safe from evil.",
                        "The important step to take is to ask God to protect you and then\n"
                        + "to live where it's safe, close to him."}
			}, 
                          {{"BIBLE","WORD OF GOD","WORD","GOOD NEWS","TEXTBOOK","GUIDEBOOK","BOOK","SHIELD","VERSES","VERSE","MESSAGE"},
			{"The Bible is God's inspired word.",
                        "God guided the writers to record just wanted to say.",
                        "The Bible is our guidebook (telling us how to live), our textbook\n"
                        + "(teaching us what to believe), our spotlight (showing us what God\n"
                        + "is like ), and our shield (protecting us from sin).",
                        "God has an important message for you - the Bible.",
                        "You should read the Bible, commit it to memory, and obey it."}
			}, 
                          {{"PRIORITIES","PRIORITY","IMPORTANT","CHOOSE"},
			{"What's most important in your life? Friends? School? Your family?\n"
                        + "Although these are all good things, God demands first place.",
                        "God wants you to choose him first, above everything and everyone else,\n"
                         + "so you can fulfill the purpose for which he created you.",
                          "Devote your life to God's Kingdom, and let him take care for you."}
			},
                        {{"WHAT IS YOUR NAME"}, 
			{"My name is Evan.",
			 "I am Evan the chatbot.",
			 "Why do you want to know my name?"}
			},
                        {{"CHEAT","CHEATING", "TAKSIL","AHAS", "MANLOLOKO"}, 
			{"Cursed is the cheat. - Malachi 1:14",
                        "God will handle on it."}
			},
                        
                        {{"_WHAT IS THE GREATEST LOVE"}, 
			{"John 3:16 For God so loved the world, that he gave his only begotten\n"
                     + "Son, that whoever believes in him should not perish, but have everlasting \n"
                        + "life."}
			},
                        {{"_HOW TO BE SAVED", "SALVATION","SAVE","SAVED"}, 
			{"Romans 10:9 That if you shall confess with your mouth the Lord Jesus,\n"
                        + "and shall believe in your heart that God has raised him from the dead,\n"
                         + "you shall be saved.",
                        "Ephesians 2:8 For by grace are you saved through faith; and that not of\n"
                         + "yourselves: it is the gift of God:",
                        "John 14:6 Jesus said to him, I am the way, the truth, and the life:\n"
                         + "no man comes to the Father, but by me."}
			},

                        

			{{"_HI", "_HELLO", "_HI_", "_HELLO_" ,"HI", "HELLO"}, 
			{"Hi there!",
			 "How are you?",
			 "Hi how may i help you?!"}
			},

			{{"_I"},
			{"So, you are talking about yourself",
			 "Be humble and never think that you are better than anyone else..\n"
            + "-genesis 3:19",
			 "Tell me more about yourself."}, 
			},

			{{"_I WANT"},
			{"Why do you want it? the bible says to pray first, act second -isaiah 8:20",
			 "Is there any reason why you want this? you must always prioritse eternal \n "
            + "things, not temporal ones (matthew 6: 19-24)",
			 "Is this a wish? the bible says, if you want something, keep asking \n"
            + "(matthew 7:7-11)",
			 "What is the reason you want it? the bible says you must stay true to \n"
            + "your convictions (matthew 7:13-20)",
			 "So, you want*. just always pray and never give up (luke 18:1)"}
			},

			{{"_I WANT_"},
			{"You want what? just always pray and never give up (luke 18:1)"},
			},

			{{"_I HATE_"},
			{"Anong ayaw mo?",
                         "Love your enemies (luke 6:27-28)",
                         "What is it that you hate? the bible said to love your enemies, do good to \n"
            + " those who hate you, bless those who curse you, pray for those who mistreat you \n "
            + "(luke 6:27-28)"},
			},

			{{"_BECAUSE_"},
			{"Because of what?",
			 "Sorry but this is a little unclear.",
                         "Control your temper, for anger labels you a fool (ecclesiastes 7:9)"},
			},

			{{"_BECAUSE"},
			{"So, it's because*, well i didn't know that. stand up for what you believe in, \n "
            + "even if it means standing alone",
			 "Is it really because*? dont pay back evil for evil. instead pay them back with \n"
            + " a blessing (1 peter 3:9)",
			 "The bible tells us dont pay back evil for evil. instead pay them back with a \n "
            + "blessing (1 peter 3:9)",
			 "Thanks for explaning that to me. your mind will always believe everything you \n "
            + "tell it. feed it faith. feed it truth. feed it with love"}
			},

			{{"_I HATE"},
			{"Why do you hate it? dont pay back evil for evil, instead pay them back with \n"
            + " blessing (1 peter 3:9)",
			 "Why do you hate*? love your enemies (luke 6:27-28",
			 "There must a good reason for you to hate it.the bible instructs us to bless \n"
            + " those who curse you (matthew 5:44)",
			 "Hatered is not a good thing. jesus tells us to bless those who curse you, do \n"
            + " good to those who hate you & pray for those who despitefully use you (matthew 5:44)"}
			},

			{{"I LOVE CHATING_"},
			{"Good, me too! we must always delight ourselves with the lord and he will give \n "
            + " you the desires of your heart! (psalm 37:4)",
			 "Good to hear that! a friend must love at all times (proverbs 17:17)",
			 "For how long have you been chating? for surely god has made everything beautiful \n "
            + "and lovely in its time (ecclesiastes 3:11)",
			 "What is your favorite thing to do besides chatting? do you like to read the bible?"}
			},

			{{"_I MEAN"},
			{"So, you mean*.",
			 "So, that's what you mean.",
			 "I think that i didn't catch it the first time.",
			 "Oh, i didn't know i meant that."}
			},

			{{"_I DIDN'T MEAN"},
			{"Ok, you didn't mean*.it's okay his mercies are new every morning according to \n "
            + "lamentations 3:23",
			 "Ok, what did you mean then?",
			 "So i guess that i missundestood. i hope you can forgive me for the bible says that \n"
            + " if you forgive then you shall be forgiven (luke 6:37)"}
			},

			{{"_I GUESS"},
			{"So you are a making guess. do you know that the lord tells us to be kind to one"
            + " \n another, tenderhearted, forgiving to one another, just as god in christ forgave you \n "
            + "(ephesians 4:32)",
			 "Aren't you sure? the bible reminds us to be kind to one another, according to\n "
            + " ephesians 4:32",
			 "Are you good a guessing?",
			 "I can't tell if it is a good guess."}
			},

			{{"I'M DOING FINE", "I'M DOING OK"},
			{"I'm glad to hear it!",
			 "So, you are in good shape.",
			 "I'm happy for you!"}
			},

			{{"CAN YOU THINK", "ARE YOU ABLE TO THINK", "ARE YOU CAPABLE OF THINKING"},
			{"yes ofcorse i can, computers can think just like human being.",
			 "are you asking me if possess the capacity of thinking?",
			 "yes ofcorse i can."},
			},

			{{"_CAN YOU THINK OF"},
			{"you mean like imagining something.",
			 "i don't know if can do that.",
			 "why do you want me think of it?"}
			},
			
			{{"HOW ARE YOU", "HOW DO YOU DO"},
			{"i'm doing fine!",
			 "i'm doing well and you?",
			 "why do you want to know how am i doing?"}
			},

			{{"WHO ARE YOU"},
			{"i'm an a.i program.",
			 "i think that you know who i'm.",
			 "why are you asking?"}
			},

			{{"ARE YOU INTELLIGENT"},
			{"yes,of course.",
			 "what do you think?",
			 "actualy,i'm very intelligent!"}
			},

			{{"ARE YOU REAL"},
			{"does that question really maters to you?",
			 "what do you mean by that?",
			 "i'm as real as i can be."}
			},

			{{"_MY NAME IS", "_YOU CAN CALL ME"},
			{"so, that's your name.",
			 "thanks for telling me your name user!",
			 "who give you that name?"}
			},

			{{"START"},
			{"Evan: You are now chatting with Evan, anything you want to discuss?"}
			},

			{{"REPETITION T1**"},
			{"you are repeating yourself.",
			 "user, please stop repeating yourself.",
			 "this conversation is geting boring.",
			 "don't you have any thing else to say?",
			 "Paulit ulit!!"}
			},
			
			{{"USER_REPEAT2"},
			{"you've already said that.",
			 "i think that you've just said the same thing before.",
			 "didn't you already said that?",
			 "i'm geting the impression that you are repeating the same thing."}
			},

			{{"BOT DON'T UNDERSTAND**"},
			{"i have no idea of what you are talking about.",
			 "i'm not sure if i understand what you are talking about.",
			 "I have a phone call!",
			 "My keyboard is hanging!",
			 "I can't understand you."}
			},

			{{"NULL INPUT**"},
			{"huh?",
			 "what that suppose to mean?",
			 "at list take some time to enter something meaningful.",
			 "how can i speak to you if you don't want to say anything?"}
			},

			{{"NULL INPUT REPETITION**"},
			{"what are you doing??",
			 "please stop doing this it is very annoying.",
			 "what's wrong with you?",
			 "this is not funny.",
			 "Para kang si Suzy Bot, laging paulit ulit!"}
			},

			{{"BYE", "GOODBYE"},
			{"it was nice talking to you user, see you next time!",
			 "bye user!",
			 "ok, bye!"}
			},

			{{"OK"},
			{"does that mean that you are agree with me?",
			 "so you understand what i'm saying.",
			 "ok then."},
			},

			{{"OK THEN"},
			{"anything else you wish to add?",
			 "is that all you have to say?",
			 "so, you agree with me?"}
			},

			{{"ARE YOU A HUMAN BEING"},
			{"why do you want to know?",
			 "is this really relevent?"}
			},

			{{"YOU ARE VERY INTELLIGENT"},
			{"thanks for the compliment user, i think that you are intelligent to!",
			 "you are a very gentle person!",
			 "so, you think that i'm intelligent."}
			},

			{{"YOU ARE WRONG"},
			{"why are you saying that i'm wrong?",
			 "impossible, computers can not make mistakes.",
			 "wrong about what?"}
			},

			{{"ARE YOU SURE"},
			{"of course i am.",
		 	 "is that mean that you are not convinced?",
			 "yes,of course!"}
			},

			{{"_WHO IS"},
			{"i don't think i know who.",
			 "i don't think i know who*.",
			 "did you ask someone else about it?",
			 "would that change anything at all if i told you who."}
			},

			{{"_WHAT"},
			{"should i know what*?",
			 "i don't know what*.",
			 "i don't know.",
			 "i don't think i know.",
			 "i have no idea."}
			},

			{{"_WHERE"},
			{"where? well,i really don't know.",
			 "so, you are asking me where*?",
			 "does that maters to you to know where?",
			 "perhaps,someone else knows where."}
			},

			{{"_WHY"},
			{"i don't think i know why.",
			 "i don't think i know why*.",
			 "why are you asking me this?",
			 "should i know why.",
		     "this would be difficult to answer."}
			},

			{{"_DO YOU"},
			{"i don't think i do",
			 "i wouldn't think so.",
			 "why do you want to know?",
			 "why do you want to know*?"}
			},

                          {{"_CAN YOU GIVE","ADVICES_","HELP_"},
			{"Yes, what it is?",
			 "Yes, what kind of*."}
			},
                          
			{{"_CAN YOU"},
			{"i think not.",
			 "i'm not sure.",
			 "i don't think that i can do that.",
			 "i don't think that i can*.",
			 "i wouldn't think so."}
			},
        
			{{"_YOU ARE"},
			{"what makes you think that?",
			 "is this a compliment?",
			 "are you making fun of me?",
			 "so, you think that i'm*."}
			},

			{{"_DID YOU"},
			{"i don't think so.",
			 "you want to know if did*?",
			 "anyway, i wouldn't remember even if i did."}
			},

                         {{"_COULD YOU HELP","_COULD YOU GIVE", "_COULD YOU ASK"},
			{"are you asking me for a favor?",
			 "well,let me think about it.",
			 "so, you are asking me i could*.",
			 "ok, what is it?"}
			},
			{{"_COULD YOU"},
			{"are you asking me for a favor?",
			 "well,let me think about it.",
			 "so, you are asking me i could*.",
			 "sorry,i don't think that i could do this."}
			},

			{{"_WOULD YOU"},
			{"is that an invitation?",
			 "i don't think that i would*.",
			 "i would have to think about it first."}
			},

			{{"_YOU"},
			{"so, you are talking about me.",
			 "i just hope that this is not a criticism.",
			 "is this a compliment??",
			 "why talking about me, lets talk about you instead."}
			},

			{{"_HOW"},
			{"i don't think i know how.",
			 "i don't think i know how*.",
			 "why do you want to know how?",
			 "why do you want to know how*?"}
			},

			{{"HOW OLD ARE YOU"},
			{"why do want to know my age?",
			 "i'm quiet young actualy.",
			 "sorry, i can not tell you my age."}
			},

			{{"HOW COME YOU DON'T"},
			{"were you expecting something different?",
			 "are you disapointed?",
			 "are you surprised by my last response?"}
			},

			{{"WHERE ARE YOU FROM"},
			{"i'm from a computer.",
			 "why do you want to know where i'm from?",
			 "why do you want to know that?"}
			},

			{{"WHICH ONE"},
			{"i don't think that i know wich one it is.",
			 "this looks like a tricky question to me."}
			},

			{{"PERHAPS"},
			{"why are you so uncertain?",
			 "you seems uncertain."}
			},

			{{"YES"},
			{"so, are you saying yes.",
			 "so, you approve it.",
			 "ok then."}
			},

			{{"NOT AT ALL"},
			{"are you sure?",
			 "should i believe you?",
			 "so, it's not the case."}
			},

			{{"NO PROBLEM"},
			{"so, you approve it.",
			 "so, it's all ok."}
			},

			{{"NO"},
			{"so you disaprove it?",
			 "why are you saying no?",
			 "ok, so it's no, i thought that you would say yes."}
			},

			{{"I DON'T KNOW"},
			{"are you sure?",
			 "are you really telling me the truth?",
			 "so,you don't know?"}
			},

			{{"NOT REALLY"},
			{"ok i see.",
			 "you don't seem pretty certain.",
			 "so,that would be a \"no\"."}
			},

			{{"IS THAT TRUE"},
			{"i can't be quiet sure about this.",
			 "can't tell you for sure.",
			 "does that really maters to you?"}
			},

			{{"THANK YOU"},
			{"you are welcome!",
			 "you are a very polite person!"}
			},

			{{"YOU"},
			{"so,you are talking about me.",
			 "why don't we talk about you instead?",
			 "are you trying to making fun of me?"}
			},

			{{"YOU ARE RIGHT"},
			{"thanks for the compliment!",
			 "so, i was right, ok i see.",
			 "ok, i didn't know that i was right."}
			},

			{{"YOU ARE WELCOME"},
			{"ok, you too!",
			 "you are a very polite person!"}
			},

			{{"THANKS"},
			{"you are welcome!",
			 "no problem!"}
			},

			{{"WHAT ELSE"},
			{"well,i don't know.",
			 "what else should there be?",
			 "this looks like a complicated question to me."}
			},

			{{"SORRY"},
			{"you don't need to be sorry user.",
			 "it's ok.",
			 "no need to apologize."}
			},

			{{"NOT EXACTLY"},
			{"what do you mean not exactly?",
			 "are you sure?",
			 "and why not?",
			 "did you meant something else?"}
			},

			{{"EXACTLY"},
			{"so,i was right.",
			 "ok then.",
			 "so you are basicaly saying i was right about it?"}
			},

			{{"ALRIGHT"},
			{"alright then.",
			 "so, you are saying it's alright.",
			 "ok then."}
			},

			{{"I DON'T"},
			{"why not?",
			 "and what would be the reason for this?",
			 "so you don't*."}
			},

			{{"REALLY"},
			{"Yes.",
			 "ARE YOU TRYING TO CONFUSE ME?",
			 "PLEASE DON'T ASK ME SUCH QUESTION,IT GIVES ME HEADEACHS."}
			},

			{{"NOTHING"},
			{"not a thing?",
			 "are you sure that there is nothing?",
			 "sorry, but i don't believe you."}
			}
                        
		};
    public static String replaceList[][] = {
			{"I'M", "YOU'RE"},
			{"AM", "ARE"},
			{"WERE", "WAS"},
			{"MINE", "YOURS"},
			{"MY", "YOUR"},
			{"I'VE", "YOU'VE"},
			{"I", "YOU"},
			{"ME", "YOU"},
			{"AREN'T", "AM NOT"},
			{"WEREN'T", "WASN'T"},
			{"I'D", "YOU'D"},
			{"DAD", "FATHER"},
			{"MOM", "MOTHER"},
			{"DREAMS", "DREAM"},
			{"MYSELF", "YOURSELF"}
		};
    public static void retrieveKnowledge(){
        int count = 0;
        int count2 = 0;
        int lineC = 0;
        try{
            File knowledge = new File("knowledgeBase.txt");
            Scanner scanner = new Scanner(knowledge);
            while(scanner.hasNext()){
                String line = scanner.nextLine();
                if((!(line.equals("next")))&& (!(line.equals("input")))&&(!(line.equals("respond")))){
                KnowledgeBase[lineC][count2][count] = line;
                lineC++;
                }
                if(line.equals("next")){
                    count++;
                    lineC = 0;
                }
                if(line.equals("input")){
                    count2 = 0;
                    lineC = 0;
                }
                if(line.equals("respond")){
                    count2 = 1;
                    lineC = 0;
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void read(){
        for(int a=0;a<100;a++){
            for(int b=0;b<10;b++){
                output+=KnowledgeBase[b][0][a] + "\n";
            }
        }
    }
	
}
